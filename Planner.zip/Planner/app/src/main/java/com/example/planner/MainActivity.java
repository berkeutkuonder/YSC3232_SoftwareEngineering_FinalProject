package com.example.planner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openBoard1 (View view) {
        Intent intent = new Intent(this, Board1Activity.class);
        startActivity(intent);
    }

    public void openBoard2 (View view) {
        Intent intent = new Intent(this, Board2Activity.class);
        startActivity(intent);
    }

    public void openBoard3 (View view) {
        Intent intent = new Intent(this, Board3Activity.class);
        startActivity(intent);
    }

    public void openBoardAdd (View view) {
        Intent intent = new Intent(this, BoardAddActivity.class);
        startActivity(intent);
    }

    public void openBoardDelete (View view) {
        Intent intent = new Intent(this, BoardAddActivity.class);
        startActivity(intent);
    }
}
